<footer class="site-footer">
    <div class="footer-content">
        <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Tutti i diritti riservati.</p>
        <p>Powered by RAID MOTOR - Ricerca Intelligente AI</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
